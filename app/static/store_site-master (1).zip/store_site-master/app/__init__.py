from .home_and_filters import *
from .product import *
from .basket import *
from .loader import app
from .login_and_admin import *
from .catalog import *
from .all_products import *
from .add_funcs import *


if __name__ == "__main__":
    app.run()

